package br.com.alura.litealura;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LiteAluraApplicationTests {

	@Test
	void contextLoads() {
	}

}
